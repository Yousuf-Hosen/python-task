class WeatherProcessor:
    